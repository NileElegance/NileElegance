/* ==========================================================================
   LOTAN — storefront logic
   Sections: language/RTL, mobile nav + search, 3D hero (Three.js),
   product rendering/filtering/sorting, quick-view modal, cart, checkout,
   info modals, newsletter, toast.
   ========================================================================== */

(function () {
  "use strict";

  const html = document.documentElement;
  const fmt = (n) => "EGP " + n.toLocaleString("en-US");
  const FREE_SHIPPING_THRESHOLD = 2000;
  const SHIPPING_FEE = 60;

  /* ---------------------------------------------------------------------
     LANGUAGE / RTL
  --------------------------------------------------------------------- */
  function applyLang(lang) {
    html.setAttribute("data-lang", lang);
    html.setAttribute("lang", lang);
    html.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
    document.querySelectorAll("[data-en-ph]").forEach((el) => {
      el.setAttribute("placeholder", lang === "ar" ? el.dataset.arPh : el.dataset.enPh);
    });
    localStorage.setItem("lotan_lang", lang);
    renderProducts();
    renderReviews();
    renderCart();
  }

  const langSwitch = document.getElementById("langSwitch");
  langSwitch.addEventListener("click", () => {
    const next = html.getAttribute("data-lang") === "ar" ? "en" : "ar";
    applyLang(next);
  });

  /* ---------------------------------------------------------------------
     MOBILE NAV + SEARCH
  --------------------------------------------------------------------- */
  const navToggle = document.getElementById("navToggle");
  const mainNav = document.getElementById("mainNav");
  navToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("is-open");
    navToggle.setAttribute("aria-expanded", open);
  });
  mainNav.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => mainNav.classList.remove("is-open"))
  );

  const searchToggle = document.getElementById("searchToggle");
  const searchBar = document.getElementById("searchBar");
  const searchInput = document.getElementById("searchInput");
  const searchClose = document.getElementById("searchClose");
  searchToggle.addEventListener("click", () => {
    searchBar.classList.add("is-open");
    searchInput.focus();
  });
  searchClose.addEventListener("click", () => searchBar.classList.remove("is-open"));
  searchInput.addEventListener("input", () => renderProducts());

  /* ---------------------------------------------------------------------
     3D HERO — Three.js stylised garment on a hanger
  --------------------------------------------------------------------- */
  function initHero3D() {
    const stage = document.getElementById("heroStage");
    const canvas = document.getElementById("garmentCanvas");
    const loading = document.getElementById("stageLoading");
    if (!window.THREE || !stage || !canvas) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(0, 0.4, 6.2);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    function resize() {
      const w = stage.clientWidth, h = stage.clientHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }

    // lighting: warm brass key + cool teal fill, evoking Cairo sun / Nile shade
    scene.add(new THREE.AmbientLight(0x2c3b3a, 0.9));
    const key = new THREE.DirectionalLight(0xe9c88a, 1.4);
    key.position.set(3, 4, 5);
    scene.add(key);
    const fill = new THREE.DirectionalLight(0x2f7a72, 0.7);
    fill.position.set(-4, -1, 2);
    scene.add(fill);

    const rig = new THREE.Group();
    scene.add(rig);

    // Garment silhouette (stylised shirt) via extruded 2D shape
    const shirt = new THREE.Shape();
    shirt.moveTo(-1.15, 1.5);
    shirt.lineTo(-0.45, 1.5);
    shirt.quadraticCurveTo(0, 1.8, 0.45, 1.5);
    shirt.lineTo(1.15, 1.5);
    shirt.lineTo(1.5, 0.75);
    shirt.lineTo(1.05, 0.55);
    shirt.lineTo(1.05, -1.9);
    shirt.lineTo(-1.05, -1.9);
    shirt.lineTo(-1.05, 0.55);
    shirt.lineTo(-1.5, 0.75);
    shirt.lineTo(-1.15, 1.5);

    const extrude = new THREE.ExtrudeGeometry(shirt, { depth: 0.22, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03, bevelSegments: 3 });
    extrude.center();
    const garmentMat = new THREE.MeshStandardMaterial({ color: 0x1f5c56, roughness: 0.75, metalness: 0.08 });
    const garment = new THREE.Mesh(extrude, garmentMat);
    garment.position.y = -0.15;
    rig.add(garment);

    // brass trim along placket
    const trimGeo = new THREE.BoxGeometry(0.05, 3.0, 0.24);
    const trimMat = new THREE.MeshStandardMaterial({ color: 0xd9b570, roughness: 0.35, metalness: 0.55 });
    const trim = new THREE.Mesh(trimGeo, trimMat);
    trim.position.set(0, -0.15, 0.01);
    rig.add(trim);

    // hanger
    const hangerGroup = new THREE.Group();
    const hookCurve = new THREE.TorusGeometry(0.22, 0.035, 8, 24, Math.PI * 1.5);
    const hangerMat = new THREE.MeshStandardMaterial({ color: 0xb8863b, roughness: 0.4, metalness: 0.6 });
    const hook = new THREE.Mesh(hookCurve, hangerMat);
    hook.rotation.z = Math.PI * 0.75;
    hook.position.y = 2.15;
    hangerGroup.add(hook);
    const barGeo = new THREE.TorusGeometry(0.95, 0.03, 8, 3);
    const bar = new THREE.Mesh(barGeo, hangerMat);
    bar.rotation.x = Math.PI / 2;
    bar.position.y = 1.85;
    bar.scale.set(1, 1, 0.55);
    hangerGroup.add(bar);
    rig.add(hangerGroup);

    // floating geometric accents (abstract, mashrabiya-lattice inspired stars — not literal icons)
    const accentGroup = new THREE.Group();
    const accentMat = new THREE.MeshStandardMaterial({ color: 0xe4eeec, roughness: 0.5, metalness: 0.1, transparent: true, opacity: 0.85 });
    for (let i = 0; i < 6; i++) {
      const geo = new THREE.OctahedronGeometry(0.09, 0);
      const m = new THREE.Mesh(geo, accentMat);
      const angle = (i / 6) * Math.PI * 2;
      const radius = 2.5 + (i % 2) * 0.4;
      m.position.set(Math.cos(angle) * radius, Math.sin(angle * 1.3) * 1.2, Math.sin(angle) * radius * 0.4);
      m.userData.baseY = m.position.y;
      m.userData.speed = 0.6 + Math.random() * 0.6;
      m.userData.offset = Math.random() * Math.PI * 2;
      accentGroup.add(m);
    }
    scene.add(accentGroup);

    resize();
    window.addEventListener("resize", resize);

    // drag-to-rotate + idle auto-rotate
    let dragging = false, lastX = 0, lastY = 0, velX = 0.004, targetRotX = 0.12;
    canvas.addEventListener("pointerdown", (e) => {
      dragging = true; lastX = e.clientX; lastY = e.clientY;
      canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener("pointerup", () => (dragging = false));
    canvas.addEventListener("pointerleave", () => (dragging = false));
    canvas.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      rig.rotation.y += dx * 0.008;
      targetRotX = THREE.MathUtils.clamp(targetRotX + dy * 0.005, -0.4, 0.5);
      velX = dx * 0.0006;
      lastX = e.clientX; lastY = e.clientY;
    });

    const clock = new THREE.Clock();
    function animate() {
      requestAnimationFrame(animate);
      const t = clock.getElapsedTime();
      if (!dragging) {
        rig.rotation.y += velX;
        velX *= 0.96;
        rig.rotation.y += 0.0022; // gentle idle spin
      }
      rig.rotation.x += (targetRotX - rig.rotation.x) * 0.08;
      accentGroup.rotation.y = t * 0.08;
      accentGroup.children.forEach((m) => {
        m.position.y = m.userData.baseY + Math.sin(t * m.userData.speed + m.userData.offset) * 0.12;
        m.rotation.x = t * 0.4;
        m.rotation.y = t * 0.3;
      });
      renderer.render(scene, camera);
    }
    animate();

    requestAnimationFrame(() => loading.classList.add("is-hidden"));
  }

  /* ---------------------------------------------------------------------
     PRODUCT RENDERING
  --------------------------------------------------------------------- */
  const productGrid = document.getElementById("productGrid");
  let activeFilter = "all";
  let activeSort = "featured";

  function lang() { return html.getAttribute("data-lang"); }

  function filteredSortedProducts() {
    const q = searchInput.value.trim().toLowerCase();
    let list = PRODUCTS.filter((p) => activeFilter === "all" || p.category === activeFilter);
    if (q) {
      list = list.filter((p) =>
        p.name.en.toLowerCase().includes(q) ||
        p.name.ar.includes(q) ||
        p.desc.en.toLowerCase().includes(q)
      );
    }
    if (activeSort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (activeSort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    if (activeSort === "featured") list = [...list].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    return list;
  }

  function renderProducts() {
    const list = filteredSortedProducts();
    const L = lang();
    productGrid.innerHTML = list.map((p) => `
      <article class="product-card" data-id="${p.id}" tabindex="0">
        <div class="pc-media" style="--tint:${p.tint}">
          <div class="pc-quick">
            <button type="button" class="pc-quickview" data-id="${p.id}">${L === "ar" ? "عرض سريع" : "Quick view"}</button>
          </div>
        </div>
        <div class="pc-body">
          <p class="pc-cat">${CATEGORY_LABELS[p.category][L]}</p>
          <h3 class="pc-name">${p.name[L]}</h3>
          <p class="pc-price">${fmt(p.price)}</p>
        </div>
      </article>
    `).join("") || `<p style="grid-column:1/-1;text-align:center;color:var(--basalt-soft)">${L === "ar" ? "لا توجد منتجات مطابقة." : "No matching products."}</p>`;

    productGrid.querySelectorAll(".product-card").forEach((card) => {
      card.addEventListener("click", (e) => {
        if (e.target.classList.contains("pc-quickview")) return;
        openProductModal(card.dataset.id);
      });
      card.addEventListener("keypress", (e) => {
        if (e.key === "Enter") openProductModal(card.dataset.id);
      });
      // subtle 3D tilt on hover, driven by pointer position
      card.addEventListener("pointermove", (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = `rotateX(${(-py * 10).toFixed(2)}deg) rotateY(${(px * 12).toFixed(2)}deg) translateY(-4px)`;
      });
      card.addEventListener("pointerleave", () => { card.style.transform = ""; });
    });
    productGrid.querySelectorAll(".pc-quickview").forEach((btn) =>
      btn.addEventListener("click", (e) => { e.stopPropagation(); openProductModal(btn.dataset.id); })
    );
  }

  document.getElementById("filterChips").addEventListener("click", (e) => {
    const chip = e.target.closest(".chip");
    if (!chip) return;
    document.querySelectorAll(".chip").forEach((c) => c.classList.remove("is-active"));
    chip.classList.add("is-active");
    activeFilter = chip.dataset.filter;
    renderProducts();
  });

  document.getElementById("sortSelect").addEventListener("change", (e) => {
    activeSort = e.target.value;
    renderProducts();
  });

  document.querySelectorAll(".category-card").forEach((card) =>
    card.addEventListener("click", () => {
      activeFilter = card.dataset.filter;
      document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("is-active", c.dataset.filter === activeFilter));
      renderProducts();
      document.getElementById("shop").scrollIntoView({ behavior: "smooth" });
    })
  );

  /* ---------------------------------------------------------------------
     REVIEWS
  --------------------------------------------------------------------- */
  function renderReviews() {
    const L = lang();
    document.getElementById("reviewTrack").innerHTML = REVIEWS.map((r) => `
      <div class="review-card">
        <div class="review-stars">${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</div>
        <p class="review-text">${r.text[L]}</p>
        <p class="review-name">${r.name}</p>
        <p class="review-city">${r.city[L]}</p>
      </div>
    `).join("");
  }

  /* ---------------------------------------------------------------------
     PRODUCT QUICK-VIEW MODAL
  --------------------------------------------------------------------- */
  const modalOverlay = document.getElementById("modalOverlay");
  const productModal = document.getElementById("productModal");
  let currentProduct = null, currentSize = null, currentQty = 1;

  function openProductModal(id) {
    const p = PRODUCTS.find((x) => x.id === id);
    if (!p) return;
    currentProduct = p; currentSize = p.sizes[0]; currentQty = 1;
    const L = lang();

    document.getElementById("pmMediaInner").style.background =
      `linear-gradient(155deg, ${p.tint} 0%, color-mix(in srgb, ${p.tint} 55%, black) 100%)`;
    document.getElementById("pmCategory").textContent = CATEGORY_LABELS[p.category][L];
    document.getElementById("pmName").textContent = p.name[L];
    document.getElementById("pmPrice").textContent = fmt(p.price);
    document.getElementById("pmDesc").textContent = p.desc[L];
    document.getElementById("pmQty").textContent = "1";

    document.getElementById("pmSizes").innerHTML = p.sizes.map((s, i) =>
      `<button type="button" data-size="${s}" class="${i === 0 ? "is-active" : ""}">${s}</button>`
    ).join("");
    document.getElementById("pmSizes").querySelectorAll("button").forEach((btn) =>
      btn.addEventListener("click", () => {
        currentSize = btn.dataset.size;
        document.querySelectorAll("#pmSizes button").forEach((b) => b.classList.remove("is-active"));
        btn.classList.add("is-active");
      })
    );

    openModal(productModal);
  }

  document.getElementById("pmQtyMinus").addEventListener("click", () => {
    currentQty = Math.max(1, currentQty - 1);
    document.getElementById("pmQty").textContent = currentQty;
  });
  document.getElementById("pmQtyPlus").addEventListener("click", () => {
    currentQty = Math.min(10, currentQty + 1);
    document.getElementById("pmQty").textContent = currentQty;
  });
  document.getElementById("pmAddToCart").addEventListener("click", () => {
    if (!currentProduct) return;
    addToCart(currentProduct, currentSize, currentQty);
    closeModal(productModal);
    showToast(lang() === "ar" ? "تمت الإضافة إلى الحقيبة" : "Added to your bag");
    openCart();
  });
  document.getElementById("pmSizeGuideLink").addEventListener("click", () => openModal(sizeGuideModal));

  /* ---------------------------------------------------------------------
     GENERIC MODAL HELPERS
  --------------------------------------------------------------------- */
  const allModals = () => document.querySelectorAll(".modal");
  function openModal(modal) {
    modalOverlay.classList.add("is-open");
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal(modal) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (![...allModals()].some((m) => m.classList.contains("is-open"))) {
      modalOverlay.classList.remove("is-open");
    }
  }
  modalOverlay.addEventListener("click", () => allModals().forEach(closeModal));
  document.getElementById("productModalClose").addEventListener("click", () => closeModal(productModal));

  const sizeGuideModal = document.getElementById("sizeGuideModal");
  document.getElementById("sizeGuideClose").addEventListener("click", () => closeModal(sizeGuideModal));
  document.getElementById("footerSizeGuide").addEventListener("click", (e) => { e.preventDefault(); openModal(sizeGuideModal); });

  const shippingModal = document.getElementById("shippingModal");
  document.getElementById("shippingModalClose").addEventListener("click", () => closeModal(shippingModal));
  document.getElementById("footerShipping").addEventListener("click", (e) => { e.preventDefault(); openModal(shippingModal); });

  const returnsModal = document.getElementById("returnsModal");
  document.getElementById("returnsModalClose").addEventListener("click", () => closeModal(returnsModal));
  document.getElementById("footerReturns").addEventListener("click", (e) => { e.preventDefault(); openModal(returnsModal); });

  /* ---------------------------------------------------------------------
     CART
  --------------------------------------------------------------------- */
  let cart = JSON.parse(localStorage.getItem("lotan_cart") || "[]");

  function saveCart() { localStorage.setItem("lotan_cart", JSON.stringify(cart)); }

  function addToCart(product, size, qty) {
    const existing = cart.find((i) => i.id === product.id && i.size === size);
    if (existing) existing.qty += qty;
    else cart.push({ id: product.id, size, qty });
    saveCart();
    renderCart();
  }

  function updateQty(id, size, delta) {
    const item = cart.find((i) => i.id === id && i.size === size);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) cart = cart.filter((i) => !(i.id === id && i.size === size));
    saveCart();
    renderCart();
  }

  function removeFromCart(id, size) {
    cart = cart.filter((i) => !(i.id === id && i.size === size));
    saveCart();
    renderCart();
  }

  function cartTotals() {
    const subtotal = cart.reduce((sum, i) => {
      const p = PRODUCTS.find((x) => x.id === i.id);
      return sum + (p ? p.price * i.qty : 0);
    }, 0);
    const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
    return { subtotal, shipping, total: subtotal + shipping };
  }

  function renderCart() {
    const L = lang();
    const cartItems = document.getElementById("cartItems");
    const cartEmpty = document.getElementById("cartEmpty");
    const cartSummary = document.getElementById("cartSummary");
    const cartCount = document.getElementById("cartCount");
    const totalQty = cart.reduce((s, i) => s + i.qty, 0);
    cartCount.textContent = totalQty;

    if (cart.length === 0) {
      cartItems.innerHTML = "";
      cartEmpty.style.display = "flex";
      cartSummary.style.display = "none";
    } else {
      cartEmpty.style.display = "none";
      cartSummary.style.display = "block";
      cartItems.innerHTML = cart.map((i) => {
        const p = PRODUCTS.find((x) => x.id === i.id);
        if (!p) return "";
        return `
          <div class="cart-item">
            <div class="cart-item-media" style="background:linear-gradient(155deg, ${p.tint}, color-mix(in srgb, ${p.tint} 55%, black))"></div>
            <div class="cart-item-info">
              <span class="cart-item-name">${p.name[L]}</span>
              <span class="cart-item-meta">${L === "ar" ? "المقاس" : "Size"}: ${i.size}</span>
              <div class="cart-item-row">
                <div class="cart-qty">
                  <button type="button" data-action="dec" data-id="${p.id}" data-size="${i.size}">−</button>
                  <span>${i.qty}</span>
                  <button type="button" data-action="inc" data-id="${p.id}" data-size="${i.size}">+</button>
                </div>
                <strong>${fmt(p.price * i.qty)}</strong>
              </div>
              <button type="button" class="cart-item-remove" data-action="remove" data-id="${p.id}" data-size="${i.size}">${L === "ar" ? "إزالة" : "Remove"}</button>
            </div>
          </div>
        `;
      }).join("");
    }

    const { subtotal, shipping, total } = cartTotals();
    document.getElementById("cartSubtotal").textContent = fmt(subtotal);
    document.getElementById("cartShipping").textContent = shipping === 0 ? (L === "ar" ? "مجاني" : "Free") : fmt(shipping);
    document.getElementById("cartTotal").textContent = fmt(total);
    document.getElementById("checkoutTotal").textContent = fmt(total);

    const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
    const pct = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);
    document.getElementById("shippingProgressFill").style.width = pct + "%";
    document.getElementById("shippingProgressText").textContent = remaining === 0
      ? (L === "ar" ? "مبروك! شحن مجاني على طلبك 🎉" : "You've unlocked free shipping 🎉")
      : (L === "ar" ? `أضف بـ ${remaining.toLocaleString("en-US")} جنيه لشحن مجاني` : `Add EGP ${remaining.toLocaleString("en-US")} more for free shipping`);
  }

  document.getElementById("cartItems").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-action]");
    if (!btn) return;
    const { action, id, size } = btn.dataset;
    if (action === "inc") updateQty(id, size, 1);
    if (action === "dec") updateQty(id, size, -1);
    if (action === "remove") removeFromCart(id, size);
  });

  const cartDrawer = document.getElementById("cartDrawer");
  const drawerOverlay = document.getElementById("drawerOverlay");
  function openCart() { cartDrawer.classList.add("is-open"); drawerOverlay.classList.add("is-open"); cartDrawer.setAttribute("aria-hidden", "false"); }
  function closeCart() { cartDrawer.classList.remove("is-open"); drawerOverlay.classList.remove("is-open"); cartDrawer.setAttribute("aria-hidden", "true"); }
  document.getElementById("cartToggle").addEventListener("click", openCart);
  document.getElementById("cartClose").addEventListener("click", closeCart);
  drawerOverlay.addEventListener("click", closeCart);
  document.getElementById("cartEmptyShop").addEventListener("click", closeCart);

  /* ---------------------------------------------------------------------
     CHECKOUT
  --------------------------------------------------------------------- */
  const checkoutModal = document.getElementById("checkoutModal");
  const govSelect = document.getElementById("governorate");
  govSelect.innerHTML = GOVERNORATES.map((g) => `<option value="${g.en}">${lang() === "ar" ? g.ar : g.en}</option>`).join("");

  document.getElementById("checkoutBtn").addEventListener("click", () => {
    if (cart.length === 0) return;
    govSelect.innerHTML = GOVERNORATES.map((g) => `<option value="${g.en}">${lang() === "ar" ? g.ar : g.en}</option>`).join("");
    closeCart();
    openModal(checkoutModal);
  });
  document.getElementById("checkoutModalClose").addEventListener("click", () => closeModal(checkoutModal));

  const confirmModal = document.getElementById("confirmModal");
  document.getElementById("checkoutForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const orderId = "LTN-" + Math.floor(100000 + Math.random() * 900000);
    document.getElementById("confirmOrderId").textContent = "#" + orderId;
    cart = [];
    saveCart();
    renderCart();
    closeModal(checkoutModal);
    openModal(confirmModal);
    e.target.reset();
  });
  document.getElementById("confirmModalClose").addEventListener("click", () => closeModal(confirmModal));
  document.getElementById("confirmClose").addEventListener("click", () => closeModal(confirmModal));

  /* ---------------------------------------------------------------------
     NEWSLETTER
  --------------------------------------------------------------------- */
  document.getElementById("newsletterForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const note = document.getElementById("newsletterNote");
    note.textContent = lang() === "ar" ? "تم الاشتراك، شكرًا لك!" : "You're subscribed — thank you!";
    document.getElementById("newsletterEmail").value = "";
  });

  /* ---------------------------------------------------------------------
     TOAST
  --------------------------------------------------------------------- */
  let toastTimer;
  function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.classList.add("is-open");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-open"), 2600);
  }

  /* ---------------------------------------------------------------------
     HEADER SHADOW ON SCROLL
  --------------------------------------------------------------------- */
  const header = document.getElementById("siteHeader");
  window.addEventListener("scroll", () => {
    header.style.boxShadow = window.scrollY > 8 ? "0 8px 24px -18px rgba(0,0,0,0.4)" : "none";
  });

  /* ---------------------------------------------------------------------
     ESC to close overlays
  --------------------------------------------------------------------- */
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      allModals().forEach(closeModal);
      closeCart();
    }
  });

  /* ---------------------------------------------------------------------
     INIT
  --------------------------------------------------------------------- */
  const savedLang = localStorage.getItem("lotan_lang") || "en";
  applyLang(savedLang);
  initHero3D();
})();
