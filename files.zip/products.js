/* ==========================================================================
   LOTAN — product catalog
   Swap this data for a real API/CMS response when you connect a backend.
   Each product has bilingual (en/ar) name + description so the whole
   storefront can flip language with no reload.
   ========================================================================== */

const PRODUCTS = [
  {
    id: "p01",
    category: "women",
    tint: "#c98a52",
    name: { en: "Nile Linen Wrap Dress", ar: "فستان لفّة كتان نايل" },
    desc: { en: "Midweight linen that softens with every wash. Cut for movement, lined at the waist.", ar: "كتان متوسط الوزن بيبقى أنعم مع كل غسلة. تفصيلة مريحة في الحركة وبطانة عند الخصر." },
    price: 1450,
    sizes: ["S", "M", "L", "XL"],
    featured: true
  },
  {
    id: "p02",
    category: "women",
    tint: "#3c6e66",
    name: { en: "Maadi Cotton Shirt", ar: "قميص قطن المعادي" },
    desc: { en: "Breathable Egyptian cotton poplin, relaxed fit, dropped shoulder.", ar: "قماش بوبلين قطن مصري خفيف، قصة واسعة، وكتف نازل." },
    price: 780,
    sizes: ["S", "M", "L"],
    featured: true
  },
  {
    id: "p03",
    category: "men",
    tint: "#1f5c56",
    name: { en: "Downtown Oxford Shirt", ar: "قميص أكسفورد وسط البلد" },
    desc: { en: "Structured oxford cotton, works from the office to a Zamalek evening.", ar: "قماش أكسفورد قطن متماسك، يناسب الشغل وسهرة في الزمالك." },
    price: 890,
    sizes: ["M", "L", "XL", "XXL"],
    featured: true
  },
  {
    id: "p04",
    category: "men",
    tint: "#8a5a3b",
    name: { en: "Nasr City Straight Jeans", ar: "جينز مستقيم مدينة نصر" },
    desc: { en: "Mid-weight stretch denim, straight leg, reinforced stitching for daily wear.", ar: "دنيم متوسط الوزن فيه مرونة، قصة مستقيمة، وخياطة متينة للاستخدام اليومي." },
    price: 1150,
    sizes: ["30", "32", "34", "36", "38"],
    featured: false
  },
  {
    id: "p05",
    category: "modern-galabeya",
    tint: "#b8863b",
    name: { en: "Aswan Modern Galabeya", ar: "جلابية أسوان العصرية" },
    desc: { en: "Tailored silhouette, side slits, hand-finished neckline in raw cotton.", ar: "قصة مفصّلة، فتحات جنبية، وياقة متشغلة يدويًا من قطن خام." },
    price: 1650,
    sizes: ["S", "M", "L", "XL"],
    featured: true
  },
  {
    id: "p06",
    category: "modern-galabeya",
    tint: "#5a5145",
    name: { en: "Luxor Kaftan", ar: "قفطان الأقصر" },
    desc: { en: "Flowing kaftan with embroidered trim, made for warm evenings.", ar: "قفطان انسيابي بحواف مطرزة، مناسب لليالي الدافية." },
    price: 1980,
    sizes: ["S/M", "L/XL"],
    featured: false
  },
  {
    id: "p07",
    category: "women",
    tint: "#c98a52",
    name: { en: "Zamalek Tailored Trousers", ar: "بنطلون مفصّل الزمالك" },
    desc: { en: "High-waist trousers in a soft twill blend, tapered leg.", ar: "بنطلون خصر عالي من قماش توِل ناعم، قصة ضيقة عند الكاحل." },
    price: 990,
    sizes: ["S", "M", "L", "XL"],
    featured: false
  },
  {
    id: "p08",
    category: "men",
    tint: "#3c6e66",
    name: { en: "Heliopolis Denim Jacket", ar: "جاكيت دنيم مصر الجديدة" },
    desc: { en: "Washed denim jacket, lightly lined, built for Cairo's short winter.", ar: "جاكيت دنيم مغسول ومبطن بشكل خفيف، مناسب لشتاء القاهرة القصير." },
    price: 1720,
    sizes: ["M", "L", "XL"],
    featured: true
  },
  {
    id: "p09",
    category: "accessories",
    tint: "#1f5c56",
    name: { en: "Khan el-Khalili Woven Belt", ar: "حزام منسوج خان الخليلي" },
    desc: { en: "Hand-woven cotton belt with a brass buckle, made by artisans in Khan el-Khalili.", ar: "حزام قطن منسوج يدويًا بإبزيم نحاسي، من صنّاع خان الخليلي." },
    price: 380,
    sizes: ["One size"],
    featured: false
  },
  {
    id: "p10",
    category: "accessories",
    tint: "#8a5a3b",
    name: { en: "Mashrabiya Tote Bag", ar: "شنطة توتيه مشربية" },
    desc: { en: "Canvas tote printed with a geometric mashrabiya pattern, leather handles.", ar: "شنطة قماش كانفاس مطبوعة بنقشة مشربية هندسية، بأيدي جلد." },
    price: 520,
    sizes: ["One size"],
    featured: true
  },
  {
    id: "p11",
    category: "women",
    tint: "#b8863b",
    name: { en: "Alexandria Breeze Blouse", ar: "بلوزة نسمة الإسكندرية" },
    desc: { en: "Lightweight viscose blouse, tie neck, made for humid coastal days.", ar: "بلوزة فيسكوز خفيفة برقبة ربطة، مناسبة لجو الساحل الرطب." },
    price: 690,
    sizes: ["S", "M", "L"],
    featured: false
  },
  {
    id: "p12",
    category: "men",
    tint: "#5a5145",
    name: { en: "Faisal Cotton Polo", ar: "بولو قطن فيصل" },
    desc: { en: "Pique cotton polo, ribbed collar, everyday fit.", ar: "بولو قطن بيكيه بياقة مضلعة وقصة يومية مريحة." },
    price: 560,
    sizes: ["S", "M", "L", "XL", "XXL"],
    featured: false
  }
];

const CATEGORY_LABELS = {
  women: { en: "Women", ar: "حريمي" },
  men: { en: "Men", ar: "رجالي" },
  "modern-galabeya": { en: "Modern Galabeya", ar: "جلابية عصرية" },
  accessories: { en: "Accessories", ar: "إكسسوارات" }
};

const REVIEWS = [
  { name: "Nourhan A.", city: { en: "Mansoura", ar: "المنصورة" }, text: { en: "Ordered the wrap dress, arrived in 3 days to Mansoura. Fabric feels premium and the fit is exactly as described.", ar: "طلبت فستان اللفة ووصل خلال ٣ أيام للمنصورة. الخامة فخمة والمقاس مظبوط زي ما هو موصوف." }, rating: 5 },
  { name: "Omar K.", city: { en: "Alexandria", ar: "الإسكندرية" }, text: { en: "The oxford shirt is genuinely good quality for the price. Paid cash on delivery, no issues at all.", ar: "قميص الأكسفورد جودته حلوة فعلاً بالنسبة للسعر. دفعت عند الاستلام وكل حاجة تمام." }, rating: 5 },
  { name: "Mariam S.", city: { en: "Cairo", ar: "القاهرة" }, text: { en: "The modern galabeya is beautiful, wore it to a family iftar and got so many compliments.", ar: "الجلابية العصرية جميلة جدًا، لبستها في إفطار عيلة واتقال لي عليها كتير." }, rating: 5 },
  { name: "Ahmed T.", city: { en: "Assiut", ar: "أسيوط" }, text: { en: "First time ordering clothes online to Assiut and it actually worked smoothly. Denim jacket fits great.", ar: "أول مرة أطلب هدوم أونلاين لأسيوط والتجربة سهلة فعلاً. جاكيت الدنيم مقاسه ظبط." }, rating: 4 },
  { name: "Yara H.", city: { en: "Tanta", ar: "طنطا" }, text: { en: "Loved the tote bag, the pattern is subtle and well made. Exchanged a size with no hassle over WhatsApp.", ar: "الشنطة حلوة جدًا والنقشة بسيطة وشغل نضيف. استبدلت المقاس من غير أي تعقيد عن طريق واتساب." }, rating: 5 }
];

const GOVERNORATES = [
  { en: "Cairo", ar: "القاهرة" },
  { en: "Giza", ar: "الجيزة" },
  { en: "Alexandria", ar: "الإسكندرية" },
  { en: "Qalyubia", ar: "القليوبية" },
  { en: "Sharqia", ar: "الشرقية" },
  { en: "Dakahlia", ar: "الدقهلية" },
  { en: "Gharbia", ar: "الغربية" },
  { en: "Monufia", ar: "المنوفية" },
  { en: "Beheira", ar: "البحيرة" },
  { en: "Kafr El Sheikh", ar: "كفر الشيخ" },
  { en: "Damietta", ar: "دمياط" },
  { en: "Port Said", ar: "بورسعيد" },
  { en: "Ismailia", ar: "الإسماعيلية" },
  { en: "Suez", ar: "السويس" },
  { en: "North Sinai", ar: "شمال سيناء" },
  { en: "South Sinai", ar: "جنوب سيناء" },
  { en: "Beni Suef", ar: "بني سويف" },
  { en: "Faiyum", ar: "الفيوم" },
  { en: "Minya", ar: "المنيا" },
  { en: "Assiut", ar: "أسيوط" },
  { en: "Sohag", ar: "سوهاج" },
  { en: "Qena", ar: "قنا" },
  { en: "Luxor", ar: "الأقصر" },
  { en: "Aswan", ar: "أسوان" },
  { en: "Red Sea", ar: "البحر الأحمر" },
  { en: "New Valley", ar: "الوادي الجديد" },
  { en: "Matrouh", ar: "مطروح" }
];
