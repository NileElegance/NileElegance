# LOTAN — Egyptian Online Clothing Store

A bilingual (Arabic/English), fully responsive online clothing store built with plain HTML/CSS/JS and a Three.js‑powered 3D hero. No build step, no framework — clone it and open `index.html`, or deploy straight to GitHub Pages.

## What's included

- **3D interactive hero** — a stylised garment-on-a-hanger built with Three.js. Users can drag to rotate it; it auto-rotates when idle. Runs entirely in the browser off the Three.js CDN build (no bundler needed).
- **3D-tilt product cards** — cards tilt toward the cursor (CSS 3D transforms driven by pointer position).
- **Arabic / English toggle** — one click flips the whole site, including layout direction (`dir="rtl"`), fonts (Reem Kufi + Cairo for Arabic, Fraunces + Cairo for English), and every string of copy. Language choice is remembered (`localStorage`).
- **Full storefront flow**: category browsing → filter/sort → quick-view modal with size + quantity → cart drawer with live shipping-progress bar → checkout → order confirmation.
- **Egypt-specific details**:
  - Prices in **EGP**.
  - **All 27 governorates** in the checkout shipping dropdown.
  - **Cash on Delivery**, **Vodafone Cash**, **InstaPay**, and card as payment options.
  - Free-shipping threshold banner (EGP 2,000) and a EGP 60 standard shipping fee.
  - A floating **WhatsApp** contact button and social links (Instagram/Facebook/TikTok).
  - Egyptian phone number format validation (`01[0125]XXXXXXXX`).
- Cart persists across page reloads via `localStorage`.
- Accessible: visible keyboard focus states, `aria-live` regions, reduced-motion support, alt-safe SVG icons.
- Fully responsive down to small phones.

## File structure

```
lotan-store/
├── index.html      # markup for every section + modal
├── style.css        # design tokens, layout, RTL rules, responsive rules
├── script.js         # language toggle, 3D scene, cart, checkout, modals
├── products.js       # product catalog, governorates, reviews (edit this to add real products)
└── README.md
```

## Running it locally

No build tools required. Either:

1. Open `index.html` directly in a browser, **or**
2. Serve it locally (recommended, avoids some browser file:// restrictions):
   ```bash
   npx serve .
   # or
   python3 -m http.server 8080
   ```

## Deploying to GitHub Pages

1. Push this folder to a GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, choose your branch (e.g. `main`) and the root folder (`/`).
4. Save — your store will be live at `https://<your-username>.github.io/<repo-name>/`.

## Customizing

- **Products**: edit the `PRODUCTS` array in `products.js`. Each product needs `id`, `category`, `tint` (a hex color used for its placeholder art — swap for a real photo by replacing the `.pc-media`/`.pm-media-inner` background with an `<img>` once you have product photography), bilingual `name`/`desc`, `price`, and `sizes`.
- **Categories**: update `CATEGORY_LABELS` in `products.js` and the four buttons in the `#categories` section of `index.html`.
- **Governorates / shipping fee / free-shipping threshold**: `GOVERNORATES` in `products.js`; `FREE_SHIPPING_THRESHOLD` and `SHIPPING_FEE` constants at the top of `script.js`.
- **WhatsApp / phone / social links**: search for `201000000000` and the social URLs in `index.html` and swap in your real numbers/handles.
- **Colors/fonts**: all design tokens are CSS custom properties at the top of `style.css` (`--sand`, `--basalt`, `--teal`, `--brass`, `--font-display`, etc.).
- **Real checkout**: the checkout form currently just clears the cart and shows a confirmation with a generated order ID — it doesn't call a payment processor. Wire `#checkoutForm`'s submit handler in `script.js` to your backend/payment provider (Paymob and Fawry are the most common Egyptian gateways) when you're ready to accept real orders.
- **Real product photography**: the current build uses generated color-gradient placeholders (`--tint`) instead of photos so the demo has no external image dependencies. Replace the `.pc-media` / `.pm-media-inner` / `.cart-item-media` divs with `<img>` tags once you have real photos.

## Browser support

Modern evergreen browsers (Chrome, Safari, Edge, Firefox). The 3D hero requires WebGL, which is supported by effectively all phones and desktops sold in the last decade; if WebGL is unavailable the rest of the store still works normally, just without the animated hero.
